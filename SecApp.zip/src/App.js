import React from 'react'
import Home2 from './pages/Home2'


const App = () => {
  return (
    <div><Home2/></div>
  )
}

export default App