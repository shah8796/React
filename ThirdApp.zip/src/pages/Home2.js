import React, { useEffect, useState, useRef } from "react";
import { FaBirthdayCake, FaDiscord } from "react-icons/fa";
import { IoMdArrowDropright } from "react-icons/io";
import { IoMdArrowDropleft } from "react-icons/io";
import { BsInstagram, BsTwitter, BsLinkedin } from "react-icons/bs";
import Aos from "aos";
import { Parallax } from "react-parallax";
import "aos/dist/aos.css";
import Typewriter from "typewriter-effect";
const Home2 = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrollingDown, setIsScrollingDown] = useState(false);
  const [isNavbarShrunk, setIsNavbarShrunk] = useState(false);
  const [marginOffset, setMarginOffset] = useState(0);
  const [marbor, setMarbor] = useState(false);
  const navscroller = () => {
    const marginFactor = 0.1;
    const scrollTop = window.scrollY;
    const padding = scrollTop / 10; // Adjust the division factor as needed
    // const navbarHeight = maxNavbarHeight - (scrollTop / 2);
    if (inputElement.current.offsetWidth > 600) {
      if (scrollTop > 20 && scrollTop < 1000) {
        setIsScrollingDown(true);
        setIsNavbarShrunk(true);
        setMarginOffset(scrollTop * marginFactor);
        inputElement2.current.style.marginLeft = `${
          scrollTop * marginFactor
        }px`;

        // inputElement.current.style.height = `${Math.max(minNavbarHeight, navbarHeight)}px`;
      } else if (scrollTop >= 1000) {
        setIsScrollingDown(true);
        setIsNavbarShrunk(true);
        // setMarginOffset(marginOffset);
        setMarbor(true);
      } else {
        setIsScrollingDown(false);
        setIsNavbarShrunk(false);
        setMarginOffset(0);
        setMarbor(false);
        inputElement2.current.style.marginLeft = `38%`;
      }
    } else if (inputElement.current.offsetWidth < 600) {
      if (scrollTop > 20 && scrollTop < 800) {
        setIsScrollingDown(true);
        setIsNavbarShrunk(true);
        setMarginOffset(scrollTop * marginFactor);

        // inputElement.current.style.height = `${Math.max(minNavbarHeight, navbarHeight)}px`;
      } else if (scrollTop >= 800) {
        setIsScrollingDown(true);
        setIsNavbarShrunk(true);
        // setMarginOffset(marginOffset);
        setMarbor(true);
      } else {
        setIsScrollingDown(false);
        setIsNavbarShrunk(false);
        setMarginOffset(0);
        setMarbor(false);
      }
    }
  };

  const inputElement = useRef();
  const inputElement2 = useRef();

  useEffect(() => {
    window.addEventListener("scroll", navscroller);
    return () => {
      window.removeEventListener("scroll", navscroller);
    };
  }, []);
  return (
    <>
      <nav
        className={`bg-black text-white py-4 px-2 sticky   top-0  ${
          isNavbarShrunk ? " " : "w-full"
        }`}
        ref={inputElement}
        style={{
          marginLeft: isScrollingDown ? `${marginOffset}px` : "0",
          marginRight: isScrollingDown ? `${marginOffset}px` : "0",
          marginTop: isScrollingDown ? `${marginOffset}px` : "0",
          borderRadius: `${marginOffset}px`,
          border: marbor ? "4px solid white" : "none",
        }}
      >
        <div className="flex justify-between">
          <div className="logo">
            <img src="/images/3MetaD.png" className="w-16 ml-20" alt="logo" />
          </div>
          <div className="block  lg:hidden" ref={inputElement2}>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className=" px-3 py-2 rounded text-black-500 hover:text-black-400"
            >
              <svg
                className={`fill-current h-8 w-8 ${
                  isOpen ? "hidden" : "block"
                }`}
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
              </svg>
              <svg
                className={`fill-current  mt-1 h-8 w-8 ${
                  isOpen ? "block" : "hidden"
                }`}
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path d="M10 8.586L2.929 1.515 1.515 2.929 8.586 10l-7.071 7.071 1.414 1.414L10 11.414l7.071 7.071 1.414-1.414L11.414 10l7.071-7.071-1.414-1.414L10 8.586z" />
              </svg>
            </button>
          </div>

          <ul
            className="hidden lg:flex lg:space-x-24 lg:tracking-tighter lg:font-semibold lg:text-lg lg:mr-20 lg:mt-5 "
            ref={inputElement2}
          >
            <li className="group cursor-pointer">
              Home
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              Collections
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              RoadMap
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              Team
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              Connect
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
          </ul>
          {/* <ul
            className={` ${
              isOpen ? "block" : "hidden"
            } flex-col  tracking-tighter font-semibold text-lg justify-center mt-10 mr-60 ml-0  lg:hidden `}
          >
            <li className="group cursor-pointer">
              Home
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              Collections
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              RoadMap
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              Team
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
            <li className="group cursor-pointer">
              Connect
              <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
            </li>
          </ul> */}
        </div>
        <ul
          className={` ${
            isOpen ? "block" : "hidden"
          } flex-col  tracking-tighter font-semibold text-lg justify-center items-center mt-10 mr-60 ml-16 bg-[#35353ff2]  lg:hidden `}
          ref={inputElement2}
        >
          <li className="group cursor-pointer">
            Home
            <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
          </li>
          <li className="group cursor-pointer">
            Collections
            <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
          </li>
          <li className="group cursor-pointer">
            RoadMap
            <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
          </li>
          <li className="group cursor-pointer">
            Team
            <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
          </li>
          <li className="group cursor-pointer">
            Connect
            <div className="w-0 border-[#FF7733] transition-[width] ease-in duration-500 group-hover:w-full group-hover:border-2"></div>
          </li>
        </ul>
      </nav>
      <div className="bg-darkforest h-[60vh] flex-col ">
        <div class="md:grid grid-cols-10 py-4">
          <div class="   pl-0 pt-36  md:col-start-3 col-span-6 md:pt-1 text-[3vw] text-[#ffffff]">
            <div className="text-[5vw] pl-36 md:text-[3vw] md:pl-32">
              GEORGE
            </div>
            <div className="text-[14px] pl-36 font-normal md:text-[16px] md:pl-32 md:font-bold">
              <Typewriter
                options={{
                  strings: ["Games and Art.", "NFTs.", "Collectible Items."],
                  autoStart: true,
                  loop: true,
                }}
              />
            </div>
            <div className="text-[14px] pl-10 pr-10 font-normal md:text-[16px] md:pl-32 md:pt-6 md:font-bold">
              George is here to clean the crypto world from ugly Pepe, the world
              most powerful meme is here to take over the crypto world, Let’s
              join the GeorgeArmy and take it to next level.
            </div>
            <button className="text-[14px] ml-32  md:mt-6 rounded-[12vw] border-0 p-1 px-2 bg-[#00D700] text-[#ffffff] text-[18px]  font-bold">
              Browse Collection
            </button>
          </div>
        </div>
      </div>
      <div className="bg-[black] ">
        <div className="text-[#ffffff] text-center text-[7vw] md:text-[2vw] py-20 font-bold ">
          Collections
        </div>
        <div className="grid grid-cols-12 gap-4 mx-20 ">
          <div className="col-start-1 col-span-12 md:col-start-1 md:col-span-3">
            <img
              src="/images/1.jpg"
              className="lg:h-96 rounded-lg"
              alt="logo"
            />
          </div>
          <div className="col-start-1 col-span-12 md:col-start-4 md:col-span-3 mt-20 md:mt-0">
            <img
              src="/images/2.jpg"
              className="lg:h-96 rounded-lg"
              alt="logo"
            />
          </div>
          <div className="col-start-1 col-span-12 md:col-start-7 md:col-span-3 mt-20 md:mt-0">
            <img
              src="/images/3.jpg"
              className="lg:h-96 rounded-lg"
              alt="logo"
            />
          </div>
          <div className="col-start-1 col-span-12 md:pb-24 md:col-start-10 md:col-span-3 mt-20 md:mt-0 ">
            <img
              src="/images/4.jpg"
              className="lg:h-96 rounded-lg"
              alt="logo"
            />
          </div>
        </div>
      </div>
      <div className="bg-[black] text-[#ffffff] pl-10 pt-28 text-[8vw] lg:text-[2vw] font-bold">
        RoadMap
      </div>
      <div className="bg-black relative h-[180%]">
        <div className="absolute left-7 lg:left-[50%] border-2 h-[140%]"></div>
        <div className="relative">
          <span className="bg-[#ff7733] mt-10 h-[60px] w-[60px] inline-flex justify-center items-center rounded-full border-white border-4 absolute left-7 lg:left-[50%] lg:transform -translate-x-1/2">
            <FaBirthdayCake className="text-2xl text-[white]" />
          </span>
          <div className="bg-gradient-to-r from-[#7a300b] to-[#ff7733] w-[75vw] lg:w-[34vw] flex-col mt-12 p-7  absolute left-[18%] lg:left-[11%] border-b-2 rounded">
            <div className="font-bold text-[white] text-lg">Website Launch</div>
            <div>🎉🎉🎉</div>
            <div className="text-[white] pt-2">Assembling of team members.</div>
          </div>
          <span className="absolute right-[80%] lg:left-[45.5%] lg:rotate-180 ml-3 mt-16">
            <IoMdArrowDropleft className="text-2xl text-[white]" />
          </span>
          <div className="hidden lg:block absolute left-[54%] mt-16 text-[white]">
            2022 - Q1
          </div>
        </div>
        <div className="relative pt-52">
          <span className="bg-[#a60404] mt-10 h-[60px] w-[60px] inline-flex justify-center items-center rounded-full border-white border-4 absolute left-7 lg:left-[50%] lg:transform -translate-x-1/2">
            <FaBirthdayCake className="text-2xl text-[white]" />
          </span>
          <div className="bg-gradient-to-r from-[#2e0804] to-[#de1610] w-[75vw] lg:w-[34vw] flex-col mt-12 p-7  absolute right-[7%] lg:right-[11%] border-b-2 rounded">
            <div className="font-bold text-[white] text-lg">Website Launch</div>
            <div>🎉🎉🎉</div>
            <div className="text-[white] pt-2">Assembling of team members.</div>
          </div>
          <span className="absolute right-[80%] lg:right-[45%] ml-3 mt-16 ">
            <IoMdArrowDropleft className="text-2xl text-[white]" />
          </span>
          <div className="hidden lg:block absolute right-[54%] mt-16 text-[white]">
            2022 - Q1
          </div>
        </div>
        <div className="relative pt-52">
          <span className="bg-[#ff7733] mt-10 h-[60px] w-[60px] inline-flex justify-center items-center rounded-full border-white border-4 absolute left-7 lg:left-[50%] lg:transform -translate-x-1/2">
            <FaBirthdayCake className="text-2xl text-[white]" />
          </span>
          <div className="bg-gradient-to-r from-[#7a300b] to-[#ff7733] w-[75vw] lg:w-[34vw] flex-col mt-12 p-7  absolute left-[18%] lg:left-[11%] border-b-2 rounded">
            <div className="font-bold text-[white] text-lg">Website Launch</div>
            <div>🎉🎉🎉</div>
            <div className="text-[white] pt-2">Assembling of team members.</div>
          </div>
          <span className="absolute right-[80%] lg:left-[45.5%] lg:rotate-180 ml-3 mt-16">
            <IoMdArrowDropleft className="text-2xl text-[white]" />
          </span>
          <div className="hidden lg:block absolute left-[54%] mt-16 text-[white]">
            2022 - Q1
          </div>
        </div>
        <div className="relative pt-52">
          <span className="bg-[#a60404] mt-10 h-[60px] w-[60px] inline-flex justify-center items-center rounded-full border-white border-4 absolute left-7 lg:left-[50%] lg:transform -translate-x-1/2">
            <FaBirthdayCake className="text-2xl text-[white]" />
          </span>
          <div className="bg-gradient-to-r from-[#2e0804] to-[#de1610] w-[75vw] lg:w-[34vw] flex-col mt-12 p-7  absolute right-[7%] lg:right-[11%] border-b-2 rounded">
            <div className="font-bold text-[white] text-lg">Website Launch</div>
            <div>🎉🎉🎉</div>
            <div className="text-[white] pt-2">Assembling of team members.</div>
          </div>
          <span className="absolute right-[80%] lg:right-[45%] ml-3 mt-16">
            <IoMdArrowDropleft className="text-2xl text-[white]" />
          </span>
          <div className="hidden lg:block  absolute right-[54%] mt-16 text-[white]">
            2022 - Q1
          </div>
        </div>
        <div className="relative pt-52">
          <span className="bg-[#a60404] h-[60px] w-[60px] inline-flex justify-center items-center text-center rounded-full border-white border-4 absolute min-[1180px]:left-[48%]">
            <p className="text-xs p-2 text-[white]">the end</p>
          </span>
          <div className="h-[50px] overflow-hidden"></div>
        </div>
      </div>
      <div>
        <Parallax bgImage="/images/metachar.jpg" strength={500}>
          {/* Main content inside the parallax */}

          {/* Nested Parallax for the image */}
          <Parallax
            renderLayer={(percentage) => (
              <div
                style={{
                  position: "absolute",
                  transform: "translate(-50%, -50%)",
                  left: "50%",
                  top: "72%",
                  width: percentage * 800,
                  height: percentage * 800,
                }}
              >
                <img src="/images/3MetaD.png" alt="logo" />
              </div>
            )}
          >
            <div className="h-[500px]"></div>
          </Parallax>
        </Parallax>
        <div className="bg-[black]">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path
              fill="#0a0b10"
              fillOpacity="1"
              d="M0,96L40,101.3C80,107,160,117,240,122.7C320,128,400,128,480,144C560,160,640,192,720,202.7C800,213,880,203,960,170.7C1040,139,1120,85,1200,74.7C1280,64,1360,96,1400,112L1440,128L1440,0L1400,0C1360,0,1280,0,1200,0C1120,0,1040,0,960,0C880,0,800,0,720,0C640,0,560,0,480,0C400,0,320,0,240,0C160,0,80,0,40,0L0,0Z"
            ></path>
          </svg>
        </div>
      </div>
      <div className="bg-[black] flex-col justify-center items-center">
        <div className="align-center text-[30px] font-bold text-[white] flex justify-center ">
          Team
        </div>

        <div className="relative group flex justify-center">
          <img
            className=" rounded-full w-[130px] h-[130px] border-[10px] border-red-800 mt-20  "
            src="/images/avatar.jpg"
            alt="avatar"
          />
          <div className="opacity-0 group-hover:opacity-80 flex items-center justify-center text-[white] absolute  bottom-[1px]  h-[130px] w-[130px] transition-all duration-300  rounded-full  bg-gradient-to-br from-[#29323c] to-[#485563] ">
            <BsTwitter className="icon" />
            <BsLinkedin className="icon" />
          </div>
        </div>
        <div className="text-base text-[white] flex justify-center mt-[2%]">
          Colombia Orc
        </div>
        <div className="text-xs text-[white] flex justify-center">
          Owner & Artist
        </div>
        <div className="text-[30px] mt-10 font-bold text-[white] flex justify-center">
          Connect
        </div>
        <div className="flex justify-center mt-8">
          <div className="w-[100px] h-[100px] text-[#ffffff56] text-[5em] pt-3 pl-3 bg-[#ffffff25] shadow-[0_20px_20px_rgba(0,0,0,0.2),0_20px_20px_rgba(253,253,253,0.2)_inset] hover:shadow-[0_20px_20px_rgba(0,0,0,0.2),0_20px_10px_rgba(255,255,255,0.8)_inset,35px_0_35px_rgba(255,119,51,1)_inset,-20px_0_20px_rgba(43,168,5,1)_inset,-35px_0_25px_rgba(0,227,4,1)_inset] hover:text-[white] hover:-translate-y-3 duration-500  rounded-[10px]  ">
            <BsInstagram />
          </div>
          <div className="w-[100px] h-[100px] text-[#ffffff56] text-[5em] pt-3 pl-3 bg-[#ffffff25] shadow-[0_20px_20px_rgba(0,0,0,0.2),0_20px_20px_rgba(253,253,253,0.2)_inset] hover:shadow-[0_20px_20px_rgba(0,0,0,0.2),0_20px_10px_rgba(255,255,255,0.8)_inset,35px_0_35px_rgba(255,119,51,1)_inset,-20px_0_20px_rgba(43,168,5,1)_inset,-35px_0_25px_rgba(0,227,4,1)_inset] hover:text-[white] hover:-translate-y-3 duration-500 rounded-[10px] ml-[2%]">
            <BsTwitter />
          </div>
          <div className="w-[100px] h-[100px] text-[#ffffff56] text-[5em] pt-3 pl-3 bg-[#ffffff25] shadow-[0_20px_20px_rgba(0,0,0,0.2),0_20px_20px_rgba(253,253,253,0.2)_inset] hover:shadow-[0_20px_20px_rgba(0,0,0,0.2),0_20px_10px_rgba(255,255,255,0.8)_inset,35px_0_35px_rgba(255,119,51,1)_inset,-20px_0_20px_rgba(43,168,5,1)_inset,-35px_0_25px_rgba(0,227,4,1)_inset] hover:text-[white] hover:-translate-y-3 duration-500 rounded-[10px] ml-[2%]">
            <FaDiscord />
          </div>
        </div>
      </div>
    </>
  );
};

export default Home2;
