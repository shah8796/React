import React from 'react'
import Home2 from './pages/Home2'
const App = () => {
  return (
    <Home2/>
  )
}

export default App